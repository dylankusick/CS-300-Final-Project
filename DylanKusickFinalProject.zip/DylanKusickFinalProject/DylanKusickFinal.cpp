/*
Dylan Kusick 

C. Ling 

CS-300 

April 15th, 2023 
*/


#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;

// Definition of structure course
struct Course {
    string courseNumber;
    string name;
    vector<string> prerequisites;
};


vector<string> tokens(string s, string del = " ") { //Split the list of strings with a space delimiter
    vector<string> array;
    int start = 0;
    int end = s.find(del);

    while (end != -1) {
        array.push_back(s.substr(start, end - start));
        start = end + del.size();
        end = s.find(del, start);
    }

    array.push_back(s.substr(start, end - start));
    return array;
}


vector<Course> LoadDataStructure() { //Load the data structure 
    cout << "File has been opened..." << endl;
    cout << "Collecting data..." << endl;
    cout << "Your data has been loaded" << endl;

    ifstream file("abcu.txt", ios::in); //Opens the file "abcu.txt"

    if (!file.is_open()) { //If the file is not open
        cout << "Failed to open file" << endl;
        exit(1);
    }

    vector<Course> courses;
    string line;

    while (getline(file, line)) { //Loops through the file and grabs each course

        Course course;

        vector<string> courseInfo = tokens(line, ","); //Course info separated by commas

        course.courseNumber = courseInfo[0]; //Store course info
        course.name = courseInfo[1];

        for (int i = 2; i < courseInfo.size(); i++) { //Stores prerequisites
            course.prerequisites.push_back(courseInfo[i]);
        }

        courses.push_back(course); //Adds the course to the list of courses
    }

    file.close(); //Close file

    return courses; //return courses
}


void printCourse(Course course) { //Prints a specific course with prerequisites

    string courseNumber = course.courseNumber;
    string name = course.name;
    vector<string> prerequisites = course.prerequisites;

    cout << "Course Number: " << courseNumber << name << endl;
    cout << "Course Name: " << name << endl;
    cout << "Prerequisites: ";

    for (int i = 0; i < prerequisites.size(); i++) {
        cout << prerequisites[i] << " ";
    }

    cout << "\n\n";
}


void printCourses(Course course) { //This prints all courses without prerequisites

    string courseNumber = course.courseNumber;
    string name = course.name;
    vector<string> prerequisites = course.prerequisites;

    cout << courseNumber << ", " << name << endl;
}


void printCourseList(vector<Course> courses) { //Print ALL courses
    int n = courses.size();
    cout << "\n";
    cout << "Here is a sample schedule:\n\n";

    for (int i = 0; i < n - 1; i++) { //Bubble sort the list of courses
        for (int j = 0; j < n - i - 1; j++) {
            if (courses[j].courseNumber > courses[j + 1].courseNumber) {
                Course temp = courses[j];
                courses[j] = courses[j + 1];
                courses[j + 1] = temp;
            }
        }
    }

    for (int i = 0; i < n; i++) { //Print courses
        printCourses(courses[i]);
    }
}



void searchCourse(vector<Course> courses) { //Searches for a specific course
    int j = courses.size(); //Limits the loop to the number of courses
    int z = 0;

    string courseNumber;

    cout << "What course do you want to know about? ";
    cin >> courseNumber;

    for (int i = 0; i < j; i++) { //Iterate through courses
        if (courses[i].courseNumber == courseNumber) { //If course is found
            z = 1;
            printCourse(courses[i]); //Print the course
            break;
        }
    }

    if (z == 0) { //If course not found
        cout << "Course is not valid, or is not in our list of courses\n";
    }
}

int main(int argc, char** argv) {

    vector<Course> courses;

    cout << "Welcome to the course planner." << "\n" << endl;
    cout << "1.Load Data Structure\n";
    cout << "2.Print Course List\n";
    cout << "3.Print Course\n";
    cout << "4.Exit\n" << endl;

    int choice = 0;

    // loop will break once user enter 4
    while (choice != 4) {

        cout << " " << endl;
        cout << "What would you like to do? ";

        cin >> choice; //User input of choices

        switch (choice) {

        case 1: {
            courses = LoadDataStructure();
            cout << "\n\n";
            cout << "1.Load Data Structure\n";
            cout << "2.Print Course List\n";
            cout << "3.Print Course\n";
            cout << "4.Exit\n";

            break;
        }

        case 2: {
            printCourseList(courses);

            cout << "\n\n";
            cout << "1.Load Data Structure\n";
            cout << "2.Print Course List\n";
            cout << "3.Print Course\n";
            cout << "4.Exit\n";

            break;
        }

        case 3: {
            searchCourse(courses);

            cout << "\n\n";
            cout << "1.Load Data Structure\n";
            cout << "2.Print Course List\n";
            cout << "3.Print Course\n";
            cout << "4.Exit\n";

            break;
        }

        case 4: {
            cout << "Thank you for using the course planner!";
            break;
        }

        default: {
            cout << choice << " is not a valid option." << endl;

            cout << "\n\n";
            cout << "1.Load Data Structure\n";
            cout << "2.Print Course List\n";
            cout << "3.Print Course\n";
            cout << "4.Exit\n";
            break;
        }
        }

    }

    return 0;
}